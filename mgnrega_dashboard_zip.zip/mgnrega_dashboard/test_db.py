#!/usr/bin/env python3
"""
Quick test to verify PostgreSQL connection
Run this before the ETL script to catch configuration issues early
"""

import psycopg2

# ⚠️ UPDATE THESE WITH YOUR CREDENTIALS
DB_CONFIG = {
    'host': 'localhost',
    'database': 'mgnrega_db',
    'user': 'postgres',
    'password': '#Ash18*',  # Change this!
    'port': 5432
}

print("Testing PostgreSQL connection...")
print(f"Connecting to: {DB_CONFIG['database']} on {DB_CONFIG['host']}")

try:
    conn = psycopg2.connect(**DB_CONFIG)
    print("✅ Connection successful!")
    
    # Test query
    with conn.cursor() as cursor:
        cursor.execute("SELECT version();")
        version = cursor.fetchone()
        print(f"✅ PostgreSQL version: {version[0]}")
    
    conn.close()
    print("✅ Connection closed properly")
    print("\n🎉 Database setup is correct! You can proceed to Step 6.")
    
except psycopg2.Error as e:
    print(f"❌ Connection failed: {e}")
    print("\n🔧 Troubleshooting:")
    print("1. Check if PostgreSQL is running")
    print("2. Verify database name is 'mgnrega_db'")
    print("3. Check username and password")
    print("4. Ensure port 5432 is not blocked")
    
except Exception as e:
    print(f"❌ Unexpected error: {e}")