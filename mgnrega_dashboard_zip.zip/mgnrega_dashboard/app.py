#!/usr/bin/env python3
"""
MGNREGA Performance Dashboard
"""

# Import necessary libraries and modules

import os
import logging
import time
import psycopg2
from psycopg2.extras import RealDictCursor # If you use this cursor, import it!
from flask import Flask, render_template, jsonify, request
from waitress import serve # <--- MUST BE HERE for the serving block
from datetime import datetime
from typing import Dict, List, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False

# Database Configuration
DB_CONFIG = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'database': os.getenv('DB_NAME', 'mgnrega_db'),
    'user': os.getenv('DB_USER', 'postgres'),
    'password': os.getenv('DB_PASSWORD', '#Ash18*'),
    'port': int(os.getenv('DB_PORT', 5432))
}

# Connection pool
db_connection = None


def get_db_connection():
    # Get database connection
    global db_connection
    
    try:
        if db_connection is None or db_connection.closed:
            logger.info("Establishing new database connection")
            db_connection = psycopg2.connect(**DB_CONFIG)
        return db_connection
    except psycopg2.Error as e:
        logger.error(f"Database connection error: {e}")
        raise


def calculate_state_averages() -> Dict[str, float]:
    """
    Calculate Maharashtra state averages for comparison
    Used to color-code district performance
    """
    try:
        conn = get_db_connection()
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            query = """
            SELECT 
                AVG(job_cards_issued) as avg_job_cards,
                AVG(households_completed_100_days) as avg_households_100,
                AVG(person_days_generated) as avg_person_days
            FROM mgnrega_performance
            WHERE month_year = (SELECT MAX(month_year) FROM mgnrega_performance)
            """
            cursor.execute(query)
            result = cursor.fetchone()
            
            if result:
                return {
                    'job_cards_issued': float(result['avg_job_cards'] or 0),
                    'households_completed_100_days': float(result['avg_households_100'] or 0),
                    'person_days_generated': float(result['avg_person_days'] or 0)
                }
    except Exception as e:
        logger.error(f"Error calculating state averages: {e}")
    
    # Return safe defaults if calculation fails
    return {
        'job_cards_issued': 75000,
        'households_completed_100_days': 25000,
        'person_days_generated': 8000000
    }


def get_performance_status(value: float, average: float) -> str:
    """
    Determine performance status based on comparison to state average
    Returns: 'excellent', 'good', or 'needs-attention'
    """
    if value >= average * 1.2:
        return 'excellent'
    elif value >= average * 0.8:
        return 'good'
    else:
        return 'needs-attention'


@app.route('/')
def index():
    """
    Homepage route - renders the main dashboard interface
    """
    return render_template('index.html')


@app.route('/api/districts')
def get_all_districts():
    """
    API endpoint to get list of all districts with latest data
    Used for dropdown selection and autocomplete
    """
    try:
        conn = get_db_connection()
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            query = """
            SELECT DISTINCT district_name
            FROM mgnrega_performance
            ORDER BY district_name
            """
            cursor.execute(query)
            districts = [row['district_name'] for row in cursor.fetchall()]
            
            return jsonify({
                'success': True,
                'districts': districts,
                'count': len(districts)
            })
    except Exception as e:
        logger.error(f"Error fetching districts: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to fetch districts'
        }), 500


@app.route('/api/district/<district_name>')
def get_district_data(district_name: str):
    """
    API endpoint to get performance data for a specific district
    Returns historical data with performance indicators
    
    Args:
        district_name: Name of the district (URL parameter)
    """
    try:
        # Validate and sanitize input
        district_name = district_name.strip()
        if not district_name:
            return jsonify({
                'success': False,
                'error': 'District name is required'
            }), 400
        
        conn = get_db_connection()
        
        # Fetch historical data for the district
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            query = """
            SELECT 
                district_name,
                month_year,
                job_cards_issued,
                households_completed_100_days,
                person_days_generated,
                last_updated
            FROM mgnrega_performance
            WHERE LOWER(district_name) = LOWER(%s)
            ORDER BY month_year DESC
            LIMIT 12
            """
            cursor.execute(query, (district_name,))
            records = cursor.fetchall()
        
        if not records:
            return jsonify({
                'success': False,
                'error': f'No data found for district: {district_name}',
                'suggestion': 'Please check the district name and try again'
            }), 404
        
        # Get state averages for comparison
        state_averages = calculate_state_averages()
        
        # Get latest record for summary
        latest = records[0]
        
        # Calculate performance status
        performance = {
            'job_cards': get_performance_status(
                latest['job_cards_issued'],
                state_averages['job_cards_issued']
            ),
            'households_100_days': get_performance_status(
                latest['households_completed_100_days'],
                state_averages['households_completed_100_days']
            ),
            'person_days': get_performance_status(
                latest['person_days_generated'],
                state_averages['person_days_generated']
            )
        }
        
        # Format response
        response = {
            'success': True,
            'district_name': latest['district_name'],
            'latest_month': latest['month_year'].strftime('%B %Y'),
            'summary': {
                'job_cards_issued': {
                    'value': latest['job_cards_issued'],
                    'status': performance['job_cards'],
                    'state_average': int(state_averages['job_cards_issued'])
                },
                'households_completed_100_days': {
                    'value': latest['households_completed_100_days'],
                    'status': performance['households_100_days'],
                    'state_average': int(state_averages['households_completed_100_days'])
                },
                'person_days_generated': {
                    'value': latest['person_days_generated'],
                    'status': performance['person_days'],
                    'state_average': int(state_averages['person_days_generated'])
                }
            },
            'historical_data': [
                {
                    'month': record['month_year'].strftime('%b %Y'),
                    'job_cards_issued': record['job_cards_issued'],
                    'households_completed_100_days': record['households_completed_100_days'],
                    'person_days_generated': record['person_days_generated']
                }
                for record in records
            ],
            'last_updated': latest['last_updated'].strftime('%Y-%m-%d %H:%M:%S')
        }
        
        return jsonify(response)
        
    except psycopg2.Error as e:
        logger.error(f"Database error for district {district_name}: {e}")
        return jsonify({
            'success': False,
            'error': 'Database error occurred'
        }), 500
    except Exception as e:
        logger.error(f"Unexpected error for district {district_name}: {e}")
        return jsonify({
            'success': False,
            'error': 'An unexpected error occurred'
        }), 500


@app.route('/api/health')
def health_check():
    """
    Health check endpoint for monitoring
    """
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("SELECT 1")
        return jsonify({
            'status': 'healthy',
            'database': 'connected',
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return jsonify({
            'status': 'unhealthy',
            'database': 'disconnected',
            'error': str(e)
        }), 503


@app.errorhandler(404)
def not_found(error):
    """Custom 404 error handler"""
    return jsonify({
        'success': False,
        'error': 'Resource not found'
    }), 404


@app.errorhandler(500)
def internal_error(error):
    """Custom 500 error handler"""
    logger.error(f"Internal server error: {error}")
    return jsonify({
        'success': False,
        'error': 'Internal server error'
    }), 500


@app.teardown_appcontext
def close_db_connection(error):
    """Close database connection when app context ends"""
    global db_connection
    if db_connection and not db_connection.closed:
        db_connection.close()
        logger.info("Database connection closed")


if __name__ == '__main__':
    # Development server (use Gunicorn/uWSGI for production)
    app.run(
        host='0.0.0.0',
        port=int(os.getenv('PORT', 5000)),
        debug=os.getenv('FLASK_ENV') == 'development'
    )
