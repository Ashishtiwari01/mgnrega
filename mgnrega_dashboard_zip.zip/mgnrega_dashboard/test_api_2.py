#!/usr/bin/env python3
"""
MGNREGA Data Ingestion ETL Script
Fetches district-level performance data for Maharashtra and loads into PostgreSQL
Designed for resilient operation with API failures and data quality issues
"""

import requests
import psycopg2
from psycopg2.extras import execute_values
from datetime import datetime
import json
import logging
import time
from typing import List, Dict, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Database Configuration (Replace with actual credentials)
DB_CONFIG = {
    'host': 'localhost',
    'database': 'mgnrega_db',
    'user': 'postgres',
    'password': '#Ash18*',
    'port': 5432
}

# API Configuration
API_BASE_URL = "https://api.data.gov.in/resource/mgnrega-performance"
API_KEY = "your_api_key_here"  # Replace with actual API key
STATE_CODE = "27"  # Maharashtra state code

# Maharashtra Districts (27 districts)
MAHARASHTRA_DISTRICTS = [
    "Mumbai", "Mumbai Suburban", "Thane", "Raigad", "Pune", "Ahmednagar",
    "Nashik", "Dhule", "Nandurbar", "Jalgaon", "Aurangabad", "Jalna",
    "Beed", "Latur", "Osmanabad", "Parbhani", "Hingoli", "Nanded",
    "Solapur", "Satara", "Ratnagiri", "Sindhudurg", "Kolhapur", "Sangli",
    "Akola", "Amravati", "Buldhana", "Washim", "Yavatmal", "Wardha",
    "Nagpur", "Bhandara", "Gondia", "Chandrapur", "Gadchiroli"
]


def create_database_schema(conn):
    """
    Create the database schema for MGNREGA performance data
    Includes indices for fast querying and constraints for data integrity
    """
    create_table_sql = """
    CREATE TABLE IF NOT EXISTS mgnrega_performance (
        id SERIAL PRIMARY KEY,
        district_name VARCHAR(100) NOT NULL,
        month_year DATE NOT NULL,
        job_cards_issued INTEGER DEFAULT 0,
        households_completed_100_days INTEGER DEFAULT 0,
        person_days_generated BIGINT DEFAULT 0,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        data_source VARCHAR(50) DEFAULT 'data.gov.in',
        UNIQUE(district_name, month_year)
    );
    
    CREATE INDEX IF NOT EXISTS idx_district_name 
        ON mgnrega_performance(district_name);
    
    CREATE INDEX IF NOT EXISTS idx_month_year 
        ON mgnrega_performance(month_year DESC);
    
    CREATE INDEX IF NOT EXISTS idx_district_month 
        ON mgnrega_performance(district_name, month_year DESC);
    """
    
    try:
        with conn.cursor() as cursor:
            cursor.execute(create_table_sql)
            conn.commit()
            logger.info("Database schema created/verified successfully")
    except Exception as e:
        logger.error(f"Error creating database schema: {e}")
        conn.rollback()
        raise


def fetch_district_data(district_name: str, retry_count: int = 3) -> Optional[List[Dict]]:
    """
    Fetch MGNREGA data for a specific district from the API
    Implements retry logic and exponential backoff for resilience
    
    Args:
        district_name: Name of the district
        retry_count: Number of retry attempts
    
    Returns:
        List of district performance records or None on failure
    """
    
    # Mock data structure for development (replace with actual API call)
    # In production, use actual API endpoint with proper authentication
    
    for attempt in range(retry_count):
        try:
            # Simulate API call with timeout
            # PRODUCTION CODE:
            # params = {
            #     'api-key': API_KEY,
            #     'format': 'json',
            #     'filters[state_code]': STATE_CODE,
            #     'filters[district_name]': district_name
            # }
            # response = requests.get(API_BASE_URL, params=params, timeout=30)
            # response.raise_for_status()
            # data = response.json()
            
            # MOCK DATA for development
            logger.info(f"Fetching data for {district_name} (attempt {attempt + 1}/{retry_count})")
            
            # Simulate realistic data with some variation
            import random
            mock_data = {
                'records': [
                    {
                        'district_name': district_name,
                        'month_year': '2024-09-01',
                        'job_cards_issued': random.randint(50000, 150000),
                        'households_completed_100_days': random.randint(10000, 50000),
                        'person_days_generated': random.randint(5000000, 15000000)
                    },
                    {
                        'district_name': district_name,
                        'month_year': '2024-10-01',
                        'job_cards_issued': random.randint(50000, 150000),
                        'households_completed_100_days': random.randint(10000, 50000),
                        'person_days_generated': random.randint(5000000, 15000000)
                    }
                ]
            }
            
            logger.info(f"Successfully fetched {len(mock_data['records'])} records for {district_name}")
            return mock_data.get('records', [])
            
        except requests.exceptions.Timeout:
            logger.warning(f"Timeout fetching data for {district_name}, attempt {attempt + 1}")
            if attempt < retry_count - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed for {district_name}: {e}")
            if attempt < retry_count - 1:
                time.sleep(2 ** attempt)
        except Exception as e:
            logger.error(f"Unexpected error fetching data for {district_name}: {e}")
            break
    
    logger.error(f"Failed to fetch data for {district_name} after {retry_count} attempts")
    return None


def transform_data(raw_records: List[Dict]) -> List[tuple]:
    """
    Transform raw API data into clean, structured format
    Handles missing values, validates data types, and normalizes fields
    
    Args:
        raw_records: Raw records from API
    
    Returns:
        List of tuples ready for database insertion
    """
    transformed = []
    
    for record in raw_records:
        try:
            # Extract and validate required fields
            district_name = str(record.get('district_name', '')).strip()
            
            # Parse date (handle various formats)
            month_year_str = record.get('month_year', '')
            try:
                month_year = datetime.strptime(month_year_str, '%Y-%m-%d').date()
            except ValueError:
                logger.warning(f"Invalid date format: {month_year_str}, skipping record")
                continue
            
            # Extract metrics with safe type conversion
            job_cards = int(record.get('job_cards_issued', 0))
            households_100_days = int(record.get('households_completed_100_days', 0))
            person_days = int(record.get('person_days_generated', 0))
            
            # Data quality checks
            if not district_name:
                logger.warning("Empty district name, skipping record")
                continue
            
            if job_cards < 0 or households_100_days < 0 or person_days < 0:
                logger.warning(f"Negative values detected for {district_name}, skipping")
                continue
            
            transformed.append((
                district_name,
                month_year,
                job_cards,
                households_100_days,
                person_days,
                datetime.now()
            ))
            
        except (ValueError, TypeError) as e:
            logger.warning(f"Error transforming record: {e}, skipping")
            continue
    
    logger.info(f"Transformed {len(transformed)} valid records")
    return transformed


def load_data(conn, transformed_data: List[tuple]):
    """
    Load transformed data into PostgreSQL using UPSERT pattern
    Handles conflicts and ensures data consistency
    
    Args:
        conn: Database connection
        transformed_data: List of tuples to insert
    """
    if not transformed_data:
        logger.warning("No data to load")
        return
    
    upsert_sql = """
    INSERT INTO mgnrega_performance 
        (district_name, month_year, job_cards_issued, 
         households_completed_100_days, person_days_generated, last_updated)
    VALUES %s
    ON CONFLICT (district_name, month_year) 
    DO UPDATE SET
        job_cards_issued = EXCLUDED.job_cards_issued,
        households_completed_100_days = EXCLUDED.households_completed_100_days,
        person_days_generated = EXCLUDED.person_days_generated,
        last_updated = EXCLUDED.last_updated
    """
    
    try:
        with conn.cursor() as cursor:
            execute_values(cursor, upsert_sql, transformed_data)
            conn.commit()
            logger.info(f"Successfully loaded {len(transformed_data)} records into database")
    except Exception as e:
        logger.error(f"Error loading data into database: {e}")
        conn.rollback()
        raise


def run_etl_pipeline():
    """
    Main ETL pipeline orchestration
    Coordinates extraction, transformation, and loading with error handling
    """
    logger.info("Starting MGNREGA ETL pipeline")
    start_time = time.time()
    
    conn = None
    successful_districts = 0
    failed_districts = 0
    
    try:
        # Establish database connection
        logger.info("Connecting to PostgreSQL database")
        conn = psycopg2.connect(**DB_CONFIG)
        
        # Create/verify schema
        create_database_schema(conn)
        
        # Process each district
        for district in MAHARASHTRA_DISTRICTS:
            logger.info(f"Processing district: {district}")
            
            # Extract
            raw_data = fetch_district_data(district)
            
            if raw_data is None:
                logger.error(f"Skipping {district} due to extraction failure")
                failed_districts += 1
                continue
            
            # Transform
            transformed_data = transform_data(raw_data)
            
            # Load
            if transformed_data:
                load_data(conn, transformed_data)
                successful_districts += 1
            else:
                logger.warning(f"No valid data to load for {district}")
                failed_districts += 1
            
            # Rate limiting - be respectful to the API
            time.sleep(0.5)
        
        # Summary statistics
        elapsed_time = time.time() - start_time
        logger.info("=" * 60)
        logger.info("ETL Pipeline Completed")
        logger.info(f"Total districts processed: {len(MAHARASHTRA_DISTRICTS)}")
        logger.info(f"Successful: {successful_districts}")
        logger.info(f"Failed: {failed_districts}")
        logger.info(f"Elapsed time: {elapsed_time:.2f} seconds")
        logger.info("=" * 60)
        
    except psycopg2.Error as e:
        logger.error(f"Database error: {e}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error in ETL pipeline: {e}")
        raise
    finally:
        if conn:
            conn.close()
            logger.info("Database connection closed")


if __name__ == "__main__":
    run_etl_pipeline()
