#!/usr/bin/env python3
"""
Data.gov.in API Diagnostic Script
Tests various API endpoints and parameter combinations to find working configuration
"""

import requests
import json
import time

# Your API Key
API_KEY = "579b464db66ec23bdd000001e7addb8b6af443ce7b18678340fa7f41"

# Resource IDs to try (from the URL you provided)
RESOURCE_IDS = [
    "baa5d77d-c2e0-4fe6-b5af-02e81629ba1c",  # From your original code
    "district-wise-mgnrega-data-glance",      # From URL slug
]

# Different API endpoint patterns
API_PATTERNS = [
    "https://api.data.gov.in/resource/{resource_id}",
    "https://api.data.gov.in/catalog/{resource_id}",
    "https://data.gov.in/api/datastore/resource/{resource_id}",
]

def test_api_endpoint(url, params):
    """Test a single API endpoint"""
    try:
        print(f"\n{'='*70}")
        print(f"Testing: {url}")
        print(f"Params: {json.dumps(params, indent=2)}")
        print(f"{'='*70}")
        
        response = requests.get(url, params=params, timeout=15)
        
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers:")
        for key, value in response.headers.items():
            if key.lower() in ['content-type', 'content-length', 'x-ratelimit-remaining']:
                print(f"  {key}: {value}")
        
        if response.status_code == 200:
            try:
                data = response.json()
                print(f"\n✅ SUCCESS! Received JSON response")
                print(f"Response structure:")
                print(f"  Type: {type(data)}")
                
                if isinstance(data, dict):
                    print(f"  Keys: {list(data.keys())}")
                    
                    # Check for records
                    if 'records' in data:
                        records = data['records']
                        print(f"  Number of records: {len(records)}")
                        if records:
                            print(f"  First record keys: {list(records[0].keys())}")
                            print(f"\n  Sample record:")
                            print(json.dumps(records[0], indent=4))
                    
                    # Check for other common keys
                    for key in ['total', 'count', 'data', 'result']:
                        if key in data:
                            print(f"  {key}: {data[key]}")
                
                elif isinstance(data, list):
                    print(f"  Length: {len(data)}")
                    if data:
                        print(f"  First item: {json.dumps(data[0], indent=4)}")
                
                return True, data
                
            except json.JSONDecodeError:
                print(f"\n⚠️ Response is not JSON")
                print(f"First 500 chars: {response.text[:500]}")
                return False, None
        
        elif response.status_code == 403:
            print(f"\n❌ FORBIDDEN - API Key might be invalid or not authorized")
            print(f"Response: {response.text[:500]}")
            return False, None
        
        elif response.status_code == 404:
            print(f"\n❌ NOT FOUND - Resource doesn't exist at this endpoint")
            return False, None
        
        elif response.status_code == 429:
            print(f"\n❌ RATE LIMITED - Too many requests")
            return False, None
        
        else:
            print(f"\n❌ Error: {response.status_code}")
            print(f"Response: {response.text[:500]}")
            return False, None
            
    except requests.exceptions.Timeout:
        print(f"\n❌ TIMEOUT - Request took too long")
        return False, None
    
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        return False, None


def main():
    """Run diagnostic tests"""
    
    print("="*70)
    print("DATA.GOV.IN API DIAGNOSTIC TOOL")
    print("="*70)
    print(f"API Key: {API_KEY[:20]}...{API_KEY[-10:]}")
    print(f"Testing at: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    
    results = []
    
    # Test different combinations
    test_configs = []
    
    # Config 1: Basic request with just API key
    for resource_id in RESOURCE_IDS:
        for pattern in API_PATTERNS:
            url = pattern.format(resource_id=resource_id)
            test_configs.append({
                'url': url,
                'params': {
                    'api-key': API_KEY,
                    'format': 'json',
                }
            })
    
    # Config 2: With filters
    for resource_id in RESOURCE_IDS:
        for pattern in API_PATTERNS:
            url = pattern.format(resource_id=resource_id)
            test_configs.append({
                'url': url,
                'params': {
                    'api-key': API_KEY,
                    'format': 'json',
                    'filters[state_name]': 'MAHARASHTRA',
                }
            })
    
    # Config 3: With limit
    for resource_id in RESOURCE_IDS:
        for pattern in API_PATTERNS:
            url = pattern.format(resource_id=resource_id)
            test_configs.append({
                'url': url,
                'params': {
                    'api-key': API_KEY,
                    'format': 'json',
                    'limit': 10,
                }
            })
    
    # Run tests
    successful_configs = []
    
    for i, config in enumerate(test_configs, 1):
        print(f"\n\nTest {i}/{len(test_configs)}")
        success, data = test_api_endpoint(config['url'], config['params'])
        
        if success and data:
            successful_configs.append({
                'config': config,
                'data': data
            })
        
        # Rate limiting
        time.sleep(1)
    
    # Summary
    print("\n\n" + "="*70)
    print("DIAGNOSTIC SUMMARY")
    print("="*70)
    print(f"Total tests run: {len(test_configs)}")
    print(f"Successful tests: {len(successful_configs)}")
    
    if successful_configs:
        print("\n✅ WORKING CONFIGURATIONS:")
        for i, result in enumerate(successful_configs, 1):
            print(f"\n{i}. URL: {result['config']['url']}")
            print(f"   Params: {result['config']['params']}")
            
            if isinstance(result['data'], dict) and 'records' in result['data']:
                print(f"   Records returned: {len(result['data']['records'])}")
    else:
        print("\n❌ NO WORKING CONFIGURATIONS FOUND")
        print("\nPossible reasons:")
        print("1. The API for this resource doesn't actually exist")
        print("2. API key needs different permissions")
        print("3. Resource ID is incorrect")
        print("4. API endpoint structure has changed")
        print("\n💡 RECOMMENDATION: Use sample data or web scraping approach")


if __name__ == "__main__":
    main()